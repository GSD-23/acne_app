# Pimples detection > 2023-01-25 7:16pm
https://universe.roboflow.com/charan-a-a-8lhwj/pimples-detection

Provided by a Roboflow user
License: CC BY 4.0

